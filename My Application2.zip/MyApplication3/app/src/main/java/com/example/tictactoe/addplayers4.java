package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class addplayers4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addplayers4);

        EditText playerOne = findViewById(R.id.playerOne);
        EditText playerTwo = findViewById(R.id.playerTwo);
        EditText playerThree = findViewById(R.id.playerThree);
        EditText playerFour = findViewById(R.id.playerFour);


        Button startGameButton = findViewById(R.id.startGameButton);

        startGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String getPlayerOneName = playerOne.getText().toString();
                String getPlayerTwoName = playerTwo.getText().toString();
                String getPlayerThreeName = playerThree.getText().toString();
                String getPlayerFourName = playerFour.getText().toString();

                if (getPlayerOneName.isEmpty() || getPlayerTwoName.isEmpty() || getPlayerThreeName.isEmpty() || getPlayerFourName.isEmpty() ) {
                    Toast.makeText(addplayers4.this, "Please enter player name", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(addplayers4.this, Players4.class);
                    intent.putExtra("playerOne", getPlayerOneName);
                    intent.putExtra("playerTwo", getPlayerTwoName);
                    intent.putExtra("playerThree", getPlayerThreeName);
                    intent.putExtra("playerFour", getPlayerFourName);
                    startActivity(intent);
                }
            }
        });


    }
}