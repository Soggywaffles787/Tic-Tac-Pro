package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.tictactoe.databinding.ActivityPlayers4Binding;

import java.util.ArrayList;
import java.util.List;

public class Players4 extends AppCompatActivity {

    ActivityPlayers4Binding binding;


    private final List<int[]> combinationList = new ArrayList<>();
    private int[] boxPositions = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; // 25 zeros
    private int playerTurn = 1;
    private int totalSelectedBoxes = 1;

    private Button undoButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        binding = ActivityPlayers4Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        combinationList.add(new int[]{0, 1, 2, 3, 4});
        combinationList.add(new int[]{5, 6, 7, 8, 9});
        combinationList.add(new int[]{10, 11, 12, 13, 14});
        combinationList.add(new int[]{15, 16, 17, 18, 19});
        combinationList.add(new int[]{20, 21, 22, 23, 24});
        combinationList.add(new int[]{0, 5, 10, 15, 20});
        combinationList.add(new int[]{1, 6, 11, 16, 21});
        combinationList.add(new int[]{2, 7, 12, 17, 22});
        combinationList.add(new int[]{3, 8, 13, 18, 23});
        combinationList.add(new int[]{4, 9, 14, 19, 24});
        combinationList.add(new int[]{0, 6, 12, 18, 24});
        combinationList.add(new int[]{4, 8, 12, 16, 20});

        String getPlayerOneName = getIntent().getStringExtra("playerOne");
        String getPlayerTwoName = getIntent().getStringExtra("playerTwo");
        String getPlayerThreeName = getIntent().getStringExtra("playerThree");
        String getPlayerFourName = getIntent().getStringExtra("playerFour");

        binding.playerOneName.setText(getPlayerOneName);
        binding.playerTwoName.setText(getPlayerTwoName);
        binding.playerThreeName.setText(getPlayerThreeName);
        binding.playerFourName.setText(getPlayerFourName);

        binding.image1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (isBoxSelectable(0)) {
                    performAction((ImageView) view, 0);
                }
            }
        });

        binding.image2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(1)) {
                    performAction((ImageView) view, 1);
                }
            }
        });

        binding.image3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(2)) {
                    performAction((ImageView) view, 2);
                }
            }
        });

        binding.image4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(3)) {
                    performAction((ImageView) view, 3);
                }
            }
        });

        binding.image5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(4)) {
                    performAction((ImageView) view, 4);
                }
            }
        });

        binding.image6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(5)) {
                    performAction((ImageView) view, 5);
                }
            }
        });

        binding.image7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(6)) {
                    performAction((ImageView) view, 6);
                }
            }
        });

        binding.image8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(7)) {
                    performAction((ImageView) view, 7);
                }
            }
        });

        binding.image9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(8)) {
                    performAction((ImageView) view, 8);
                }
            }
        });

        binding.image10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(9)) {
                    performAction((ImageView) view, 9);
                }
            }
        });

        binding.image11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(10)) {
                    performAction((ImageView) view, 10);
                }
            }
        });

        binding.image12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(11)) {
                    performAction((ImageView) view, 11);
                }
            }
        });

        binding.image13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(12)) {
                    performAction((ImageView) view, 12);
                }
            }
        });

        binding.image14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(13)) {
                    performAction((ImageView) view, 13);
                }
            }
        });

        binding.image15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(14)) {
                    performAction((ImageView) view, 14);
                }
            }
        });

        binding.image16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(15)) {
                    performAction((ImageView) view, 15);
                }
            }
        });

        binding.image17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(16)) {
                    performAction((ImageView) view, 16);
                }
            }
        });

        binding.image18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(17)) {
                    performAction((ImageView) view, 17);
                }
            }
        });

        binding.image19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(18)) {
                    performAction((ImageView) view, 18);
                }
            }
        });

        binding.image20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(19)) {
                    performAction((ImageView) view, 19);
                }
            }
        });

        binding.image21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(20)) {
                    performAction((ImageView) view, 20);
                }
            }
        });

        binding.image22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(21)) {
                    performAction((ImageView) view, 21);
                }
            }
        });

        binding.image23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(22)) {
                    performAction((ImageView) view, 22);
                }
            }
        });

        binding.image24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(23)) {
                    performAction((ImageView) view, 23);
                }
            }
        });

        binding.image25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(24)) {
                    performAction((ImageView) view, 24);
                }
            }
        });

        undoButton = findViewById(R.id.undo_button);

        undoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                undoLastMove();
            }
        });






    }
        private void performAction(ImageView imageView, int selectedBoxPosition) {
            boxPositions[selectedBoxPosition] = playerTurn;

            if (playerTurn == 1) {
                imageView.setImageResource(R.drawable.ximage);
                if (checkResults()) {
                    ResultDialog resultDialog = new ResultDialog(Players4.this, binding.playerOneName.getText().toString()
                            + " is the Winner!", Players4.this);
                    resultDialog.setCancelable(false);
                    resultDialog.show();
                } else if (totalSelectedBoxes == 25) {
                    ResultDialog resultDialog = new ResultDialog(Players4.this, "Match Draw", Players4.this);
                    resultDialog.setCancelable(false);
                    resultDialog.show();
                } else {
                    changePlayerTurn(2);
                    totalSelectedBoxes++;
                }
            } else if (playerTurn == 2) {
                imageView.setImageResource(R.drawable.oimage);
                if (checkResults()) {
                    ResultDialog resultDialog = new ResultDialog(Players4.this, binding.playerTwoName.getText().toString()
                            + " is the Winner!", Players4.this);
                    resultDialog.setCancelable(false);
                    resultDialog.show();
                } else if (totalSelectedBoxes == 25) {
                    ResultDialog resultDialog = new ResultDialog(Players4.this, "Match Draw", Players4.this);
                    resultDialog.setCancelable(false);
                    resultDialog.show();
                } else {
                    changePlayerTurn(3);
                    totalSelectedBoxes++;
                }
            } else if (playerTurn == 3) {
                imageView.setImageResource(R.drawable.triangleimage);
                if (checkResults()) {
                    ResultDialog resultDialog = new ResultDialog(Players4.this, binding.playerThreeName.getText().toString()
                            + " is the Winner!", Players4.this);
                    resultDialog.setCancelable(false);
                    resultDialog.show();
                } else if (totalSelectedBoxes == 25) {
                    ResultDialog resultDialog = new ResultDialog(Players4.this, "Match Draw", Players4.this);
                    resultDialog.setCancelable(false);
                    resultDialog.show();
                } else {
                    changePlayerTurn(4);
                    totalSelectedBoxes++;
                }
            } else if (playerTurn == 4) {
                imageView.setImageResource(R.drawable.boximage);
                if (checkResults()) {
                    ResultDialog resultDialog = new ResultDialog(Players4.this, binding.playerFourName.getText().toString()
                            + " is the Winner!", Players4.this);
                    resultDialog.setCancelable(false);
                    resultDialog.show();
                } else if (totalSelectedBoxes == 25) {
                    ResultDialog resultDialog = new ResultDialog(Players4.this, "Match Draw", Players4.this);
                    resultDialog.setCancelable(false);
                    resultDialog.show();
                } else {
                    changePlayerTurn(1);
                    totalSelectedBoxes++;
                }
            }
        }

        private void changePlayerTurn(int currentPlayerTurn) {
            playerTurn = currentPlayerTurn;
            if (playerTurn == 1) {
                binding.playerOneLayout.setBackgroundResource(R.drawable.black_border);
                binding.playerTwoLayout.setBackgroundResource(R.drawable.white_box);
                binding.playerThreeLayout.setBackgroundResource(R.drawable.white_box);
                binding.playerFourLayout.setBackgroundResource(R.drawable.white_box);
            } else if (playerTurn == 2) {
                binding.playerTwoLayout.setBackgroundResource(R.drawable.black_border);
                binding.playerOneLayout.setBackgroundResource(R.drawable.white_box);
                binding.playerThreeLayout.setBackgroundResource(R.drawable.white_box);
                binding.playerFourLayout.setBackgroundResource(R.drawable.white_box);
            } else if (playerTurn == 3) {
                binding.playerThreeLayout.setBackgroundResource(R.drawable.black_border);
                binding.playerOneLayout.setBackgroundResource(R.drawable.white_box);
                binding.playerTwoLayout.setBackgroundResource(R.drawable.white_box);
                binding.playerFourLayout.setBackgroundResource(R.drawable.white_box);
            } else if (playerTurn == 4) {
                binding.playerFourLayout.setBackgroundResource(R.drawable.black_border);
                binding.playerOneLayout.setBackgroundResource(R.drawable.white_box);
                binding.playerTwoLayout.setBackgroundResource(R.drawable.white_box);
                binding.playerThreeLayout.setBackgroundResource(R.drawable.white_box);
            }
        }

        private boolean checkResults() {
            boolean response = false;
            for (int i = 0; i < combinationList.size(); i++) {
                final int[] combination = combinationList.get(i);

                if (boxPositions[combination[0]] == playerTurn && boxPositions[combination[1]] == playerTurn &&
                        boxPositions[combination[2]] == playerTurn && boxPositions[combination[3]] == playerTurn &&
                        boxPositions[combination[4]] == playerTurn) {
                    response = true;
                    break;
                }
            }
            return response;
        }

        private boolean isBoxSelectable(int boxPosition) {
            boolean response = false;
            if (boxPositions[boxPosition] == 0) {
                response = true;
            }
            return response;
        }

        private String getPlayerName(int player) {
            if (player == 1) {
                return binding.playerOneName.getText().toString();
            } else if (player == 2) {
                return binding.playerTwoName.getText().toString();
            } else if (player == 3) {
                return binding.playerThreeName.getText().toString();
            } else if (player == 4) {
                return binding.playerFourName.getText().toString();
            } else {
                return "";
            }
        }

        private int getPlayerImage(int player) {
            if (player == 1) {
                return R.drawable.ximage;
            } else if (player == 2) {
                return R.drawable.oimage;
            } else if (player == 3) {
                return R.drawable.triangleimage;
            } else if (player == 4) {
                return R.drawable.boximage;
            } else {
                return 0;
            }
        }

        public void restartMatch() {
            boxPositions = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; // 25 zeros
            playerTurn = 1;
            totalSelectedBoxes = 1;

            // Reset the image views to their initial state (white_box)
            binding.image1.setImageResource(R.drawable.white_box);
            binding.image2.setImageResource(R.drawable.white_box);
            binding.image3.setImageResource(R.drawable.white_box);
            binding.image4.setImageResource(R.drawable.white_box);
            binding.image5.setImageResource(R.drawable.white_box);
            binding.image6.setImageResource(R.drawable.white_box);
            binding.image7.setImageResource(R.drawable.white_box);
            binding.image8.setImageResource(R.drawable.white_box);
            binding.image9.setImageResource(R.drawable.white_box);
            binding.image10.setImageResource(R.drawable.white_box);
            binding.image11.setImageResource(R.drawable.white_box);
            binding.image12.setImageResource(R.drawable.white_box);
            binding.image13.setImageResource(R.drawable.white_box);
            binding.image14.setImageResource(R.drawable.white_box);
            binding.image15.setImageResource(R.drawable.white_box);
            binding.image16.setImageResource(R.drawable.white_box);
            binding.image17.setImageResource(R.drawable.white_box);
            binding.image18.setImageResource(R.drawable.white_box);
            binding.image19.setImageResource(R.drawable.white_box);
            binding.image20.setImageResource(R.drawable.white_box);
            binding.image21.setImageResource(R.drawable.white_box);
            binding.image22.setImageResource(R.drawable.white_box);
            binding.image23.setImageResource(R.drawable.white_box);
            binding.image24.setImageResource(R.drawable.white_box);
            binding.image25.setImageResource(R.drawable.white_box);
        }

        public void onBackPressed(){
        new AlertDialog.Builder(this)
                .setMessage("Are you sure you want to Exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        finish();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void undoLastMove() {
        // Find the last selected box
        int lastSelectedBoxIndex = -1;
        for (int i = boxPositions.length - 1; i >= 0; i--) {
            if (boxPositions[i] != 0) {
                lastSelectedBoxIndex = i;
                break;
            }
        }

        if (lastSelectedBoxIndex >= 0) {
            boxPositions[lastSelectedBoxIndex] = 0; // Set the box position to 0 (empty)
            totalSelectedBoxes--; // Decrement the total selected boxes count
            // Reset the corresponding ImageView to white_box
            ImageView imageView = getImageViewByPosition(lastSelectedBoxIndex);
            imageView.setImageResource(R.drawable.white_box);

            // Change the player turn
            if (playerTurn == 1) {
                changePlayerTurn(4);
            } else {
                changePlayerTurn(playerTurn - 1);
            }
        }
    }



    private ImageView getImageViewByPosition(int position) {
        switch (position) {
            case 0:
                return binding.image1;
            case 1:
                return binding.image2;
            case 2:
                return binding.image3;
            case 3:
                return binding.image4;
            case 4:
                return binding.image5;
            case 5:
                return binding.image6;
            case 6:
                return binding.image7;
            case 7:
                return binding.image8;
            case 8:
                return binding.image9;
            case 9:
                return binding.image10;
            case 10:
                return binding.image11;
            case 11:
                return binding.image12;
            case 12:
                return binding.image13;
            case 13:
                return binding.image14;
            case 14:
                return binding.image15;
            case 15:
                return binding.image16;
            case 16:
                return binding.image17;
            case 17:
                return binding.image18;
            case 18:
                return binding.image19;
            case 19:
                return binding.image20;
            case 20:
                return binding.image21;
            case 21:
                return binding.image22;
            case 22:
                return binding.image23;
            case 23:
                return binding.image24;
            case 24:
                return binding.image25;
            default:
                return null;
        }
    }





}
