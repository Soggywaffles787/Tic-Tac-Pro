package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class players extends AppCompatActivity {
    private Button twoplayersButton;
    private Button threeplayersButton;
    private Button fourplayersButton;

    private Button help;

    private Button leaderboard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_players);

        twoplayersButton = (Button) findViewById(R.id.twoplayersButton);
        twoplayersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity2();
            }
        });

        threeplayersButton = (Button) findViewById(R.id.threeplayersButton);
        threeplayersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity3();
            }
        });

        fourplayersButton = (Button) findViewById(R.id.fourplayersButton);
        fourplayersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity4();
            }
        });

        help = (Button) findViewById(R.id.help);
        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity5();
            }
        });

        leaderboard = (Button) findViewById(R.id.leaderboard);
        leaderboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity6();
            }
        });

    }
    public void openActivity6(){
        Intent intent = new Intent(this, leaderboards.class);
        startActivity(intent);
    }
    public void openActivity5(){
        Intent intent = new Intent(this, help.class);
        startActivity(intent);
    }
    public void openActivity2(){
        Intent intent = new Intent(this, AddPlayers.class);
        startActivity(intent);
    }


    public void openActivity3(){
        Intent intent = new Intent(this, addplayers3.class);
        startActivity(intent);
    }

    public void openActivity4(){
        Intent intent = new Intent(this, addplayers4.class);
        startActivity(intent);
    }
    }
