package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.tictactoe.databinding.ActivityPlayers3Binding;

import java.util.ArrayList;
import java.util.List;

public class Players3 extends AppCompatActivity {

    ActivityPlayers3Binding binding;
    private final List<int[]> combinationList = new ArrayList<>();
    private int[] boxPositions = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; // 16 zeros
    private int playerTurn = 1;
    private int totalSelectedBoxes = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPlayers3Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        combinationList.add(new int[]{0, 1, 2, 3});
        combinationList.add(new int[]{4, 5, 6, 7});
        combinationList.add(new int[]{8, 9, 10, 11});
        combinationList.add(new int[]{12, 13, 14, 15});
        combinationList.add(new int[]{0, 4, 8, 12});
        combinationList.add(new int[]{1, 5, 9, 13});
        combinationList.add(new int[]{2, 6, 10, 14});
        combinationList.add(new int[]{3, 7, 11, 15});
        combinationList.add(new int[]{0, 5, 10, 15});
        combinationList.add(new int[]{3, 6, 9, 12});

        String getPlayerOneName = getIntent().getStringExtra("playerOne");
        String getPlayerTwoName = getIntent().getStringExtra("playerTwo");
        String getPlayerThreeName = getIntent().getStringExtra("playerThree");

        binding.playerOneName.setText(getPlayerOneName);
        binding.playerTwoName.setText(getPlayerTwoName);
        binding.playerThreeName.setText(getPlayerThreeName);

        binding.image1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (isBoxSelectable(0)) {
                    performAction((ImageView) view, 0);
                }
            }
        });

        binding.image2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(1)){
                    performAction((ImageView) view, 1);
                }
            }
        });

        binding.image3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(2)){
                    performAction((ImageView) view, 2);
                }
            }
        });

        binding.image4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(3)){
                    performAction((ImageView) view, 3);
                }
            }
        });

        binding.image5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(4)){
                    performAction((ImageView) view, 4);
                }
            }
        });

        binding.image6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(5)){
                    performAction((ImageView) view, 5);
                }
            }
        });

        binding.image7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(6)){
                    performAction((ImageView) view, 6);
                }
            }
        });

        binding.image8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(7)){
                    performAction((ImageView) view, 7);
                }
            }
        });

        binding.image9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(8)){
                    performAction((ImageView) view, 8);
                }
            }
        });

        binding.image10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(9)){
                    performAction((ImageView) view, 9);
                }
            }
        });

        binding.image11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(10)){
                    performAction((ImageView) view, 10);
                }
            }
        });

        binding.image12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(11)){
                    performAction((ImageView) view, 11);
                }
            }
        });

        binding.image13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(12)){
                    performAction((ImageView) view, 12);
                }
            }
        });

        binding.image14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(13)){
                    performAction((ImageView) view, 13);
                }
            }
        });

        binding.image15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(14)){
                    performAction((ImageView) view, 14);
                }
            }
        });

        binding.image16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isBoxSelectable(15)){
                    performAction((ImageView) view, 15);
                }
            }
        });

        binding.btnUndo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                undoLastMove();
            }
        });

    }
    private void undoLastMove() {
        if (totalSelectedBoxes > 1) {
            // Decrement the total selected boxes count
            totalSelectedBoxes--;

            // Find the last selected box position
            int lastSelectedBoxPosition = -1;
            for (int i = boxPositions.length - 1; i >= 0; i--) {
                if (boxPositions[i] != 0) {
                    lastSelectedBoxPosition = i;
                    break;
                }
            }

            if (lastSelectedBoxPosition != -1) {
                // Clear the last selected box
                boxPositions[lastSelectedBoxPosition] = 0;

                // Find the ImageView associated with the last selected box position
                ImageView imageView = getImageViewForPosition(lastSelectedBoxPosition);

                if (imageView != null) {
                    // Reset the ImageView to its initial state (white_box)
                    imageView.setImageResource(R.drawable.white_box);

                    // Change the player turn
                    changePlayerTurn(playerTurn == 1 ? 3 : playerTurn - 1);
                }
            }
        }
    }

    private void performAction(ImageView  imageView, int selectedBoxPosition) {
        boxPositions[selectedBoxPosition] = playerTurn;

        if (playerTurn == 1) {
            imageView.setImageResource(R.drawable.ximage);
            if (checkResults()) {
                ResultDialog resultDialog = new ResultDialog(Players3.this, binding.playerOneName.getText().toString()
                        + " is a Winner!", Players3.this);
                resultDialog.setCancelable(false);
                resultDialog.show();
            } else if(totalSelectedBoxes == 16) {
                ResultDialog resultDialog = new ResultDialog(Players3.this, "Match Draw", Players3.this);
                resultDialog.setCancelable(false);
                resultDialog.show();
            } else {
                changePlayerTurn(2);
                totalSelectedBoxes++;
            }
        } else if (playerTurn == 2) {
            imageView.setImageResource(R.drawable.oimage);
            if (checkResults()) {
                ResultDialog resultDialog = new ResultDialog(Players3.this, binding.playerTwoName.getText().toString()
                        + " is a Winner!", Players3.this);
                resultDialog.setCancelable(false);
                resultDialog.show();
            } else if(totalSelectedBoxes == 16) {
                ResultDialog resultDialog = new ResultDialog(Players3.this, "Match Draw", Players3.this);
                resultDialog.setCancelable(false);
                resultDialog.show();
            } else {
                changePlayerTurn(3);
                totalSelectedBoxes++;
            }
        } else {
            imageView.setImageResource(R.drawable.triangleimage);
            if (checkResults()) {
                ResultDialog resultDialog = new ResultDialog(Players3.this, binding.playerThreeName.getText().toString()
                        + " is a Winner!", Players3.this);
                resultDialog.setCancelable(false);
                resultDialog.show();
            } else if(totalSelectedBoxes == 16) {
                ResultDialog resultDialog = new ResultDialog(Players3.this, "Match Draw", Players3.this);
                resultDialog.setCancelable(false);
                resultDialog.show();
            } else {
                changePlayerTurn(1);
                totalSelectedBoxes++;
            }
        }
    }
    private void changePlayerTurn(int currentPlayerTurn) {
        playerTurn = currentPlayerTurn;
        if (playerTurn == 1) {
            binding.playerOneLayout.setBackgroundResource(R.drawable.black_border);
            binding.playerTwoLayout.setBackgroundResource(R.drawable.white_box);
            binding.playerThreeLayout.setBackgroundResource(R.drawable.white_box);
        } else if (playerTurn == 2) {
            binding.playerTwoLayout.setBackgroundResource(R.drawable.black_border);
            binding.playerOneLayout.setBackgroundResource(R.drawable.white_box);
            binding.playerThreeLayout.setBackgroundResource(R.drawable.white_box);
        } else {
            binding.playerThreeLayout.setBackgroundResource(R.drawable.black_border);
            binding.playerOneLayout.setBackgroundResource(R.drawable.white_box);
            binding.playerTwoLayout.setBackgroundResource(R.drawable.white_box);
        }
    }

    private boolean checkResults() {
        boolean response = false;
        for (int i = 0; i < combinationList.size(); i++) {
            final int[] combination = combinationList.get(i);

            if (boxPositions[combination[0]] == playerTurn && boxPositions[combination[1]] == playerTurn &&
                    boxPositions[combination[2]] == playerTurn && boxPositions[combination[3]] == playerTurn) {
                response = true;
                break;
            }
        }
        return response;
    }

    private boolean isBoxSelectable(int boxPosition) {
        boolean response = false;
        if (boxPositions[boxPosition] == 0) {
            response = true;
        }
        return response;
    }

    private String getPlayerName(int player) {
        if (player == 1) {
            return binding.playerOneName.getText().toString();
        } else if (player == 2) {
            return binding.playerTwoName.getText().toString();
        } else {
            return binding.playerThreeName.getText().toString();
        }
    }

    private int getPlayerImage(int player) {
        if (player == 1) {
            return R.drawable.ximage;
        } else if (player == 2) {
            return R.drawable.oimage;
        } else {
            return R.drawable.triangleimage;
        }
    }

    public void restartMatch() {
        boxPositions = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; // 16 zeros
        playerTurn = 1;
        totalSelectedBoxes = 1;

        // Reset the image views to their initial state (white_box)
        binding.image1.setImageResource(R.drawable.white_box);
        binding.image2.setImageResource(R.drawable.white_box);
        binding.image3.setImageResource(R.drawable.white_box);
        binding.image4.setImageResource(R.drawable.white_box);
        binding.image5.setImageResource(R.drawable.white_box);
        binding.image6.setImageResource(R.drawable.white_box);
        binding.image7.setImageResource(R.drawable.white_box);
        binding.image8.setImageResource(R.drawable.white_box);
        binding.image9.setImageResource(R.drawable.white_box);
        binding.image10.setImageResource(R.drawable.white_box);
        binding.image11.setImageResource(R.drawable.white_box);
        binding.image12.setImageResource(R.drawable.white_box);
        binding.image13.setImageResource(R.drawable.white_box);
        binding.image14.setImageResource(R.drawable.white_box);
        binding.image15.setImageResource(R.drawable.white_box);
        binding.image16.setImageResource(R.drawable.white_box);
    }

    public void onBackPressed(){
        new AlertDialog.Builder(this)
                .setMessage("Are you sure you want to Exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        finish();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }
    private ImageView getImageViewForPosition(int position) {
        switch (position) {
            case 0:
                return binding.image1;
            case 1:
                return binding.image2;
            case 2:
                return binding.image3;
            case 3:
                return binding.image4;
            case 4:
                return binding.image5;
            case 5:
                return binding.image6;
            case 6:
                return binding.image7;
            case 7:
                return binding.image8;
            case 8:
                return binding.image9;
            case 9:
                return binding.image10;
            case 10:
                return binding.image11;
            case 11:
                return binding.image12;
            case 12:
                return binding.image13;
            case 13:
                return binding.image14;
            case 14:
                return binding.image15;
            case 15:
                return binding.image16;
            default:
                return null;
        }
    }



}